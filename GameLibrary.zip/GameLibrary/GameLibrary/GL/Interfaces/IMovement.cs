﻿using System.Drawing;

namespace GameLibrary.GL.Interfaces
{
    public interface IMovement
    {
        Point Move(Point location);
    }
}
