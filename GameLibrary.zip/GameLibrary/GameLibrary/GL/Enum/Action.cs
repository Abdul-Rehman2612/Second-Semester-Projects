﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLibrary.GL.Enum
{
    public enum Action
    {
        RemovePlayer,
        RemoveEnemy,
        RemoveBullet,
        RemoveEB,
        DoNothing,
        IncreaseScore
    }
}
