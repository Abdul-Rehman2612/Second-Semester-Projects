﻿namespace GameLibrary.GL.Enum
{
    public enum Direction
    {
        Left,
        Right,
        Up,
        Down,
        DiagUpRight,
        DiagUpLeft,
        DiagDownLeft,
        DiagDownRight
    }
}