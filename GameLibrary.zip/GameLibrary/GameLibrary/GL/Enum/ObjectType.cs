﻿namespace GameLibrary.GL.Enum
{
    public enum ObjectType
    {
        Player,
        Enemy,
        Wall,
        Bullet,
        Reward
    }
}